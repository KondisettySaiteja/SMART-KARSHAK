<?php
ini_set("include_path", '/home/lgyhfv3v/php:contactus.php' . ini_get("include_path") );
$First=$_POST['first'];
$Last=$_POST['last'];
$Email=$_POST['email'];
$Contact=$_POST['contact'];
$Place=$_POST['place'];
$Query=$_POST['query'];
$connection= mysqli_connect("mysql7002.site4now.net","lgyhfv3v_smkr","paddu123","lgyhfv3v_smartkarshak");
mysqli_query($connection,"INSERT INTO `details`(`FirstName`, `LastName`, `Emailid`, `ContactNumber`, `Place`, `query`)
VALUES ('$First','$Last','$Email','$Contact','$Place','$Query')") ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style1.css">
<head>
  <style media="screen">
  body{
    border: 10px solid blue;
  }
    iframe{
      position: absolute;
      right: 20px;
      top: 140px;
    }
    .submit{
      background-color: grey;

      border: 0px solid blue;\
      border-top: 0px;
      margin: 0px;
      color: thick black;
      font-weight: bold;
    }
     .submit form {
      font-size: 1em;
      margin-bottom: 10px;
    }

  </style>
<title>contactus</title></head>
<body>
  <div class="navbar">
    <a href="index.html">Home</a>
    <a href="about.html">About Us</a>
      <a href="product.html">Product</a>
        <a href="gallery.html">Gallery</a>
    <div class="dropdown">
      <button class="dropbtn" style="text-align:center">User Guide
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="software.html">Software Installation</a>
        <a href="hardware.html">Hardware Installation</a>

      </div>
    </div>
    <a class="active" href="contactus.php">Contact Us</a>
  </div>

<table
 style="width: 100%; text-align: left; margin-left: auto; margin-right: auto;"
 border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color: rgb(105, 111, 246);"><big><big><big><big><big>&nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;<span
 style="font-weight: bold;">Contact Us</span></big></big></big></big></big></td>
    </tr>
  </tbody>
</table>
<br>
<br><br><br><br>
<h1><big>Address:</big></h1>
<big><big>#N3-46 Silpa Lepakshi Nagar,<br>
Near S.K University, <br>
Anantapuram<br>
</big></big>
<h2><big><big>Contact:</big></big></h2>
<big><big><span style="font-weight: bold;">Sales</span>:+918008208822
,<span style="font-weight: bold;"> Support:</span>+916300229336</big></big><br>
<big><big><big><span style="font-weight: bold;">Email</span>:
info@smartkarshak.com</big></big></big>
<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d53241.968728959466!2d77.59359934743175!3d14.630664234420172!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e4!4m3!3m2!1d14.6314655!2d77.6280166!4m5!1s0x3bb14bbf83d71343%3A0x92e6b3b54c384131!2sSilpa+Lepakshi+Nagar%2C+Ram+Nagar%2C+Anantapur%2C+Andhra+Pradesh+515003!3m2!1d14.629868199999999!2d77.6292215!5e1!3m2!1sen!2sin!4v1524299385432"
width="400" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
<div class="submit">
<form class="form" action="contactus.php" method="post">
  <label for="first">FIRST NAME:</label><br>
  <input type="text" name="first" value="" required><br>
  <label for="last">LAST NAME:</label><br>
  <input type="text" name="last" value=""required><br>
  <label for="email">EMAIL ID:</label><br>
  <input type="text" name="email" value=""required><br>
  <label for="contact">CONTACT NUMBER:</label><br>
  <input type="text" name="contact" value=""required><br>
  <label for="place">PLACE:</label><br>
  <input type="text" name="place" value=""required><br>
  <label for="query">QUERY</label><br>
  <textarea id="query" name="query" placeholder="Write something.." style="height:200px"style="width:100px" ></textarea><br>
  <input class="sub" type="submit" name="submit" value="SUBMIT"><br>
</form>
</div>
</body>
</html>
